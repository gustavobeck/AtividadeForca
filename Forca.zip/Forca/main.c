#include <stdio.h>
#include <stdlib.h>
#include "forca.h"

int main()
{
    printf("Desenvolvido por Gustavo Beck e Lucas Miranda\n\n");
    NoSecreto * listaSecreta = inicializaListaSecreta();

    listaSecreta = carregaListaArquivo(listaSecreta,"E:\\Forca\\palavras.dat");

    imprimeListaSecreta(listaSecreta);
    return 0;
}
